export default {
  plugins: {},
};