# ReelsPRO Browser Extension - Source Code Package

This is the complete source code package for Firefox Add-ons (AMO) review.

## 🚀 Quick Build

```bash
npm install
npm run build:firefox
```

The built extension will be in `extension-firefox.zip`.

## 📋 Complete Instructions

See **BUILD_INSTRUCTIONS.md** for comprehensive step-by-step build instructions.

## 📦 What's Included

- **src/** - All source code (not minified, except content.js which is transpiled by Vite)
- **scripts/** - Build scripts (build-firefox.cjs, build-chrome.cjs)
- **tfjs/** - TensorFlow.js library files
- **package.json** - Dependencies and build scripts
- **package-lock.json** - Locked dependency versions for reproducible builds
- **manifest-firefox.json** - Firefox extension manifest
- **vite.config.js** - Vite build configuration
- **BUILD_INSTRUCTIONS.md** - Comprehensive build guide

## ✅ Build Requirements

- Node.js 18+ (tested with v22.21.0)
- npm 8+ (tested with v10.9.4)
- Operating System: Linux, macOS, or Windows

## 🔧 Build Process

1. Install dependencies: `npm install`
2. Build extension: `npm run build:firefox`
3. Output: `extension-firefox.zip` (~18MB)

## 📝 Notes for Reviewers

- Only `src/content.js` is transpiled to `dist/content.js` using Vite (open source)
- All other source files are included in their original, non-minified form
- The NSFW detection model files (~20MB) are included in `src/assets/models/nsfwjs/`
- Build is 100% reproducible using the included `package-lock.json`

## 📚 Documentation

- BUILD_INSTRUCTIONS.md - Step-by-step build guide
- ReelsPRO_Browser-Extension_README.MD - Extension overview
- PROJECT_ARCHITECTURE.md - Architecture documentation

## 📧 Contact

For questions: contact2abhaygupta@gmail.com
Repository: https://github.com/Abs6187/ReelsPRO
